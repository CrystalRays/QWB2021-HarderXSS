<?php
session_start();
header("Content-Type: application/javascript; charset=UTF-8");
if(array_key_exists("secret",$_GET) && array_key_exists("callback",$_GET)){
    if($_GET["secret"]===file_get_contents('../visitor/flag')){
        die( "$_GET[callback]('Welcome! Secret is your flag!')");
    }
    die( "$_GET[callback]('Control center access require a vaild secret key. You entered a invaild secret!')");
}
die("alert('params?')");
?>

