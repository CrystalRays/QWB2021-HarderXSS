<script >
document.domain="cubestone.com";
function pageload(data){
    document.body.innerText=data;
}
<?php 
if(array_key_exists("secret",$_GET)){
    echo "fetch(`loader.php?callback=pageload&secret=$_GET[secret]`).then((res)=>{return res.text();}).then((data)=>{eval(data);})";
}
?>
</script>
