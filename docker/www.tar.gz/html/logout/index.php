<?php
session_start();
// var_dump($_SESSION);
// var_dump(session_id());
$_SESSION["login"]=0;
echo "<script>document.location='/';</script>";