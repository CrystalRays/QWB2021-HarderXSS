<?php
session_start();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>用户反馈中心</title>
    <!--自定义函数-->
    <script>
        function unopen() {
            alert('功能暂时未开放');
        }
    </script>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- HTML5 shim 和 Respond.js 是为了让 IE8 支持 HTML5 元素和媒体查询（media queries）功能 -->
    <!-- 警告：通过 file:// 协议（就是直接将 html 页面拖拽到浏览器中）访问页面时 Respond.js 不起作用 -->
    <!--[if lt IE 9]>
    <script src="https://cdn.jsdelivr.net/npm/html5shiv@3.7.3/dist/html5shiv.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/respond.js@1.4.2/dest/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="https://feedback.cubestone.com">主页</a>
        <a class="navbar-brand" href="JavaScript:unopen();">所有反馈</a>
        <a class="navbar-brand" href="/submit">提交反馈</a>
        <a class="navbar-brand" href="JavaScript:unopen();">我的反馈</a>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav navbar-right">
            <?php 
            if(!array_key_exists("login",$_SESSION)){
                $_SESSION["login"]=0;
            }
            if($_SESSION["login"]!==0){
            ?>
                <li><a href="/user/"><?php echo $_SESSION["name"]?></a></li>
                <li><a href="/logout">退出登陆</a></li>
            <?php
            }
            else {?>
                    <li><a href="/login/">登陆</a></li>
                    <li><a href="javascript:unopen();">注册</a></li>
                    <?php
            }
            ?>
            
                    </ul>
    </div><!-- /.navbar-collapsesss -->
</nav>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">

</nav>

<div class="alert alert-warning" role="alert">
    <strong>请先登陆</strong>
</div>
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion"
               href="#collapseTwo">
                更新日志
            </a>
        </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse in">
        <div class="panel-body">
            2021-6-3: 可以提交反馈了，虽然你们看不了，不过我能看到
            <br>
            2021-6-2: 外部引用很好用，但是也很危险，不过我解决了这个问题
            <br>
            2021-6-1: 为用户头像功能开创性地支持了矢量图
            <br> 
            2021-5-31: 测试同学说我用户模块有问题，先暂时下线注册功能吧
            <br>
            2021-5-31：用户可以上传头像了
            <br>
            2021-5-30：接入了主站的用户系统，登录状态可以在所有子域下同步
            <br>
            2021-5-29： 用户反馈中心项目立项
        </div>
    </div>
</div>
<div class="panel panel-default">
    <div class="panel-heading">
        <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion"
               href="#collapseTwo">
                开发规划
            </a>
        </h4>
    </div>
<div id="collapseTwo" class="panel-collapse collapse in">
        <div class="panel-body">
            反馈提交功能
            <br> 
            反馈查阅功能
            <br>
            反馈进度跟踪功能
        </div>
</div>
</div>


<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
</body>
</html>