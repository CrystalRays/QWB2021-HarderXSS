<?php
session_start();
if(array_key_exists("login",$_SESSION)){
    if($_SESSION["login"]!==0){
        if(!array_key_exists("link",$_POST) || !array_key_exists("vcode",$_POST)|| !array_key_exists("vcode",$_SESSION)){
            die("<script>alert('非法请求');document.location='/submit/'</script>");
        }
        if(!preg_match("/http:\/\/|https:\/\//i",$_POST["link"])){
            die("<script>alert('需要http(s)头');document.location='/submit/'</script>");
        }
        if(preg_match("/flaaaaaaaag\.cubestone\.com|127\.|\[::1\]|localhost/i",$_POST["link"])){
            die("<script>alert('Hacker! How can you access our Intranet!');document.location='/submit/'</script>");
        }
        if($_SESSION["vcode"]!==substr(md5($_POST["vcode"]),0,5)){
            die("<script>alert('验证码有误!');document.location='/submit/'</script>");
        }
        $link=preg_replace(array('/\\\/','/\\"/'),array("\\\\\\","\\\""),$_POST["link"]);
        exec("node /var/www/visitor/index.js \"$link\" >> /var/www/visitor/log/log");
        die("<script>alert('反馈已收到!');document.location='/submit/'</script>");
    }
}
die("<script>alert('请先登录');document.location='/submit/'</script>");
