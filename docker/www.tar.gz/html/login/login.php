<?php
session_start();
if(!array_key_exists("username",$_POST) || !array_key_exists("password",$_POST)){
    die("<script>alert('用户名密码错误');document.location='/login/'</script>");
}
$con=new mysqli("localhost","ctf","123456","ctf");
if(preg_match("/insert|update|sleep|union|updatexml|extractvalue|join| |from|where|table|floor|exp|limit|group|concat|if/i",$_POST["username"])){
    die("<script>alert('You!Hacker!');document.location='/';</script>");
}
$res=$con->query("select id,password from user where username='$_POST[username]' and password='".md5($_POST["password"])."'");
if($res){
    $set=$res->fetch_row();
    if($set){
        $_SESSION["login"]=intval($set[0]);
        $_SESSION["name"]=$_POST["username"];
        if ( $_SESSION["login"]===1){
            die("<script>document.location='/admin/'</script>");
        }
        die("<script>document.location='/'</script>");
    }
}
$_SESSION["login"]=0;
die("<script>alert('用户名密码错误');document.location='/login/'</script>");

?>