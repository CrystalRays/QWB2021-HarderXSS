<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>用户反馈中心</title>
    <!--自定义函数-->
    <script>
        function unopen() {
            alert('功能暂时未开放');
        }
        function preview(){
            var reader= new FileReader();
            var file=document.querySelector("input").files[0];
            reader.readAsDataURL(file);
//             document.querySelector("#prebox").src=reader.result;
            reader.addEventListener("load", function () {
    document.querySelector("#prebox").src = reader.result;
  }, false);
        }
        upload=()=>{
            $.post("upload.php",data=`data=${encodeURIComponent(document.querySelector("#prebox").src)}`,(data,status)=>{
                alert(data);
            });
        }
        </script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-default" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="https://feedback.cubestone.com">主页</a>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse navbar-ex1-collapse">
        <ul class="nav navbar-nav navbar-right">
        <?php 
        session_start();
            if(!array_key_exists("login",$_SESSION)){
                $_SESSION["login"]=0;
            }
            if($_SESSION["login"]!==0){
            ?>
                <li><a href="/user/"><?php echo $_SESSION["name"]?></a></li>
                <li><a href="/logout">退出登陆</a></li>
            <?php
            }
            else { ?>
                    <script>alert('请先登录');document.location='/login/'</script>
            <?php
            }
            ?>
                    </ul>
    </div><!-- /.navbar-collapsesss -->
</nav>
<nav class="navbar navbar-default navbar-fixed-bottom" role="navigation">

</nav>

<div style="padding: 100px 100px 10px;">
    <h2>修改头像</h2>
    <ul class="list-group">
        <li class="list-group-item">头像上传</li>
        <li class="list-group-item">
        <form action="javascript:upload()"><input name="file" type="file" accept="image/gif, image/jpeg,image/png,image/svg+xml" onchange="preview(this);"><button type="submit" >上传</button></form>
        </li>
        <li class="list-group-item">头像预览</li>
        <li class="list-group-item">

<embed id="prebox" src="<?php 
$con=new mysqli("localhost","ctf","123456","ctf");
$res=$con->query("select img from avatar where userid=$_SESSION[login]");
$img=$res->fetch_row();
echo $img[0];
?>" > 

        
        </li>
    </ul>            
</div>


<!-- jQuery (Bootstrap 的所有 JavaScript 插件都依赖 jQuery，所以必须放在前边) -->
<script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
<!-- 加载 Bootstrap 的所有 JavaScript 插件。你也可以根据需要只加载单个插件。 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js"></script>
</body>
</html>