<?php
session_start();
// ini_set("display_errors","off");
// error_reporting(0);
if(!array_key_exists("login",$_SESSION)){
    die("login first");
}
else if($_SESSION["login"]===0){
    die("login first");
}
$encode=$_POST["data"];
if(substr($encode,0,5)!="data:"){
    die("You!Hacker!");
}
$decode=file_get_contents($encode);
// var_dump($decode);
if(!(substr($decode,0,2)==="\xFF\xD8" or substr($decode,0,2)==="BM" or substr($decode,0,2)=="\x89\x50" or substr($decode,0,2)==="GI")){
    // libxml_disable_entity_loader(true);
    $dom = new DOMDocument();
    $res=$dom->loadXML($decode,LIBXML_DTDLOAD);
    if(!$res)
        die("Not Image!");
    $decode1=$dom->saveXML();
    // highlight_string($deocde1);
    //防止本地文件读取
    if(preg_match("/file:|data:|zlib:|php:\/\/stdin|php:\/\/input|php:\/\/fd|php:\/\/memory|php:\/\/temp|expect:|ogg:|rar:|glob:|phar:|ftp:|ssh2:|bzip2:|zip:|ftps:/i",$decode1,$matches))
        die("unsupport protocol: ".$matches[0]);
    if(preg_match("/\/var|\/etc|\.\.|\/proc/i",$decode1,$matches)){
        die("Illegal URI: ".$matches[0]);
    }
    $res=$dom->loadXML($decode,LIBXML_NOENT);
    if(!$res)
        die("Not Image!");
    $decode=$dom->saveXML();
    
    // highlight_string($decode);
    //防止xss
    if(preg_match("/script|object|embed|onload\s*=/i",$decode))
        die("no script!");
    // $encode="data:image/svg+xml;base64,".base64_encode($decode);
}
$filename=md5(rand());
file_put_contents("../upload/".$filename,$decode);
$filename='/upload/'.$filename;
$con=new mysqli("localhost","ctf","123456","ctf");
$res=$con->query("select img from avatar where userid=$_SESSION[login]");
if($res){
    if($res->fetch_row()){
        // echo "update avatar set img='$filename' where userid=$_SESSION[login]";
        $res=$con->query("update avatar set img='$filename' where userid=$_SESSION[login]");
        if($res!==TRUE){
            // echo $con->error;
            $con->close();
        }
        die("update success");
    }
}
$res=$con->query("insert into avatar values($_SESSION[login],'$filename')");
$con->commit();
die("upload success");
