
const CDP = require("chrome-remote-interface");
const exec =require('child_process').exec; 
var visitime=0;
CDP(client => {
  // extract domains
  const { Network, Page ,Runtime } = client;
  // setup handlers
  Network.requestWillBeSent(params => {
    // console.log(params.request);
  });
  Network.responseReceived(params=>{
    // console.log(params.response);
  })
  Page.loadEventFired(async() => {
    if(++visitime>8){
      client.close();
      process.exit(1);
    }
    console.log(new Date());
    let res= await Runtime.evaluate({expression:"location.pathname;"});
    console.log(res.result.value);
    if (res.result.value=="/login/") {
      res= await Runtime.evaluate({expression:"document.querySelector('input[name=username]').value=`admin`;document.querySelector(`input[name=password]`).value=`sooooooooooooooooooooooooooooeasy`;document.querySelector(`input[name=submit]`).click();"});
    } else if(res.result.value=='/admin/'){
      res= await Runtime.evaluate({expression:`location='${process.argv.slice(2)}';`});
    }
    else{
      // console.log(res.result);
      res= await Runtime.evaluate({expression:"location.hostname;"});
      console.log(res.result.value);
      if(res.result.value=='flaaaaaaaag.cubestone.com'){
        client.close();
        process.exit();
      }
      setTimeout(() => {
        exec('cat /var/www/visitor/flag',(err,stdout,stderr)=>{
          Page.navigate({ url: `https://flaaaaaaaag.cubestone.com/?secret=${stdout}` });
        });
      }, 1000);
    }
  });
  // enable events then start!
  Promise.all([Network.enable(), Page.enable(),Runtime.enable()])
    .then(() => {
      return Page.navigate({ url: "https://feedback.cubestone.com/login/" });
    })
    .catch(err => {
      console.error(err);
      client.close();
    });
}).on("error", err => {
  // cannot connect to the remote endpoint
  console.error(err);
});
