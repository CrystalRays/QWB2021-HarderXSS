#! /bin/bash

rm -r cubestone.com demoCA

mkdir -p ./demoCA/{private,newcerts} && \
    touch ./demoCA/index.txt && \
    touch ./demoCA/serial && \
    echo 01 > ./demoCA/serial

openssl genrsa -out ./demoCA/private/cakey.pem 2048
openssl req -new -x509 -key ./demoCA/private/cakey.pem -out ./demoCA/cacert.pem -days 7300 -config ./root.conf -subj "/CN=cubestone Authority CA/OU=cubestone.com/O=cubestone.com/ST=Shanghai/L=Shanghai/C=CN"
openssl x509 -inform PEM -in ./demoCA/cacert.pem -outform DER -out ./demoCA/CA.crt
mkdir ./cubestone.com
openssl genrsa -out ./cubestone.com/cubestone.com.key 2048
openssl req -new -key ./cubestone.com/cubestone.com.key -out ./cubestone.com/cubestone.com.csr -config ./server.conf -subj "/CN=cubestone Authority CA/OU=cubestone.com/O=cubestone.com/ST=Shanghai/L=Shanghai/C=CN"
echo -e "y\ny"| openssl ca -in ./cubestone.com/cubestone.com.csr -out ./cubestone.com/cubestone.com.crt -days 3650 -extensions x509_ext -extfile ./server.conf

cp ./demoCA/cacert.pem /usr/local/share/ca-certificates/cacert.crt
update-ca--certificates 
